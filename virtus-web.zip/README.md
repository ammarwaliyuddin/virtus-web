# virtus-web
teknologi
- ci 4
- mysql
- boostrap 4

sistem informasi dan monitoring perangkat iot smartwatch

#clone repostori ini
1. program .env tidak ada, jdi pakai yang sebelumnya

jika masih eror silahkan update composer

composer update --ignore-platform-reqs

jika ada perubahan pada databases, 
tolong upload file sql di folder DB
