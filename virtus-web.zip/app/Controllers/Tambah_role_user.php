<?php

namespace App\Controllers;

class Tambah_role_user extends BaseController
{
    public function index()
    {
        return view('Pengaturan/Tambah_role_user');
    }
}
