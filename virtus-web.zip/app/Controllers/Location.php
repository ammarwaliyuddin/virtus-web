<?php

namespace App\Controllers;

class Location extends BaseController
{
    public function index()
    {
        return view('Location/Location');
    }

    //--------------------------------------------------------------------

}
