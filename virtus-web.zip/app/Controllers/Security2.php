<?php

namespace App\Controllers;

class Security2 extends BaseController
{
    public function index()
    {
        return view('Security/Security2');
    }
}
